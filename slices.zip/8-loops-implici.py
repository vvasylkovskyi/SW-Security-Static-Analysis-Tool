a=b('nis')
c=""
while (i == a) :
   c=c + "xpto1"
   i = t(i)
w(s("oi",c))

# tip: while loops can encode implicit flows

