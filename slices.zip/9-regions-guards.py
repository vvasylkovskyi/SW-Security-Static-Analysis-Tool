a=b('nis')
c=d('oi')
i=""
while (a != "") :
    f = s(c,0,1)

    if (f=="a") :
        i = i + "'"
    else :
        i = i + " "
    a = s(a,1)
z(0,i)

# tip: implicit flows can come from any of the nested conditions/loops
