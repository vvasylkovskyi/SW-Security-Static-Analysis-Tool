a=b('nis')
c=""
d=""
while (e == "") :
    c = d
    if (x == 33) :
        d = a
    a = s(a+1)
q=z(c)

# tip: different control paths, via number of loops, might encode or not different vulnerablities. 
