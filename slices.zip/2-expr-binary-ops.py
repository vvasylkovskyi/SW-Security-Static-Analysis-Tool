a=b()
c=s("ola",a)
f=e(c+"oi"+d+"hi",a)

# tip: expressions might involve binary operations with arguments of different levels, arguments of sanitizers and sinks can also be expressions, and sanitized and unsanitized data can reach sinks simultaneously

