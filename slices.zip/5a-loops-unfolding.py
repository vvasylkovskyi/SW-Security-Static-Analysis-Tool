a=b('nis')
while (e == "") :
    c = d(a)
    e = f(c)
    a = e
g = h(a)

# tip: sources, sanitizers and sinks can appear inside loops
